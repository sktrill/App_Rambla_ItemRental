﻿namespace otr_project.ViewModels
{
    public class RentalCartRemoveViewModel
    {
        public string Message { get; set; }
        public decimal CartTotal { get; set; }
        public int DeleteId { get; set; }
        public int CartCount { get; set; }
    }
}