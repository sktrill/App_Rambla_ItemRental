﻿namespace otr_project.ViewModels
{
    public class LogOnAjaxViewModel
    {
        public string Message { get; set; }
        public bool Error { get; set; }
    }
}